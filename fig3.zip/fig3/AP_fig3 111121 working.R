library(tidyverse)
library(ggplot2)


#5 built from #4 but with legend adjustments ----------------------------------------------

library(showtext)
library(ggtext)

font_add_google(family="patua-one", "Patua One")
font_add_google(family="roboto", "Roboto")

showtext_auto()

APfig3 %>%
  
  filter(AP >0) %>%
  dplyr::filter(Class == "Soma")%>%
  #filter(ROIum >10) %>%
  filter(ROIorder <7) %>%
  #filter( cellAreaum > 0 ) %>%
  
  ggplot() +
  geom_point(aes(x = CircumferenceUm, y = AreaUm, size = ObjectDiameterUm, alpha = 1, color = Image))+
  #scale_color_manual(name ="Treatment groups", values = colors3)+
  scale_size_continuous(name="size") +
  scale_alpha(name = 'alpha')+
  guides(colour = guide_legend(override.aes = list(size=4)))+
  #guides(alpha=FALSE)+ # turn off specific legend alpha
  
  #mutate(ROIorder = recode(ROIorder, "1" = "2.6 to 2.8"))+ not working
  
  facet_grid(~ROIorder)+
  theme_classic()+
  
  xlab("x lab")+
  ylab("y lab")+
  
  labs(title = "Characterization of Iba1+ microglia in the striatum of a viral infection mouse model", # inserting "\n" in a string codes for a line break ex "happyn\birthday"
       subtitle = "",
       #caption = "<b>figure X: Comparison of TH+ cells across treatments:</b> Results suggest the treatment may affect the total number of cells and cell size in the anterior protion of the SN. Each point represents data extracted from the SN by hemisphere</i>", #<i> italics, <b> bold, <br> break
       tag = "",
       color = NULL,
       alpha = NULL)+
  
  theme(
    plot.title = element_text(family = "patua-one", size=26, hjust = .6),
    #plot.title.position = "plot",
    plot.caption = element_textbox_simple(hjust =0.5, lineheight = 1), #textbox_simple does what markdown does but will autowrap texts "markdown includes html to render but needs ggtext in library loaded figure zero is left justified, one is right, and 0.5 is center
    plot.subtitle =element_text(size = 95),
    axis.text.x = element_text(family ="patua-one", size = 12, face = "bold", color = "black"),
    axis.text.y = element_text(family ="patua-one", size = 12, face = "bold", color = "black"),
    axis.title.x = element_text(family =, size=20, face = "bold"),
    axis.title.y = element_text(family =, size=20, face = "bold"),
    legend.title = element_text(family =, size = 12, face = "bold", color = "black"),
    legend.text = element_text(family =, size = 10, face = "bold", color = "black"),
  )
#colors3 <- c("3m En1/SYN" = "#D92D37", "3m WT/PBS" = "black", "1m En1/SYN" = "#4F71B6", "1m WT/PBS" = "#1C8255")
colors3 <- c("Viral Infection" = "#27866D")

ggsave("THSN practicing in R.tiff", width = 36, height = 17.278) # this part isn't working so well       
# intersting code for changing things in the data frame ex: 
#  y_position = rev(1:nrow(.))) %>%
#    mutate(insert column title here = recode(same column title here, "data you want to change" = "what you want to change it to"))
# also to remove rows from data frame
# filter(column name here !> "string in row you want to remove")