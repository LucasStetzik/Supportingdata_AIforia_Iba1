library(tidyverse)
library(ggplot2)


#Built from Fig3 summary forRstudio111221 ----------------------------------------------

library(showtext)
library(ggtext)

font_add_google(family="helvetica", "Patua One")
font_add_google(family="roboto", "Roboto")

showtext_auto()

APDfig3 %>%
  
  filter(AP >0) %>%
  dplyr::filter(Class == "Soma")%>%
  #filter(ROIum >10) %>%
  filter(ROIorder <7) %>%
  #filter( cellAreaum > 0 ) %>%
  
  ggplot() +
  geom_jitter(width = 0.11, height = 0.11, aes(x = treatmentR2, y = Count, size = 1, alpha = 1.5, color = treatmentR2,))+
  scale_color_manual(name ="Treatment groups", values = c("Viral infection" = "#326E49", "PBS" = "#8777A2"))+
  #scale_size_continuous(name="Cell diameter μm") +
  #scale_alpha(name = "Area:Perimeter")+
  guides(colour = guide_legend(override.aes = list(size=4)))+
  guides(alpha=FALSE)+ # turn off specific legend alpha
  guides(size=FALSE)+
  
  
  #mutate(ROIorder = recode(ROIorder, "1" = "2.6 to 2.8"))+ not working
  
  #facet_grid(~ROIorder)+
  theme_classic()+
  
  xlab("Cell diameter μm")+
  ylab("Counts")+
  
  labs(title = NULL, # inserting "\n" in a string codes for a line break ex "happyn\birthday"
       subtitle = NULL,
       #caption = "<b>figure X: Comparison of TH+ cells across treatments:</b> Results suggest the treatment may affect the total number of cells and cell size in the anterior protion of the SN. Each point represents data extracted from the SN by hemisphere</i>", #<i> italics, <b> bold, <br> break
       tag = "",
       color = NULL,
       alpha = NULL)+
  
  theme(
    plot.title = element_text(family = "helvetica", size=26, hjust = .6),
    #plot.title.position = "plot",
    plot.caption = element_textbox_simple(hjust =0.5, lineheight = 1), #textbox_simple does what markdown does but will autowrap texts "markdown includes html to render but needs ggtext in library loaded figure zero is left justified, one is right, and 0.5 is center
    plot.subtitle =element_text(size = 95),
    axis.text.x = element_text(family ="helvetica", size = 12, face = "bold", color = "black"),
    axis.text.y = element_text(family ="helvetica", size = 12, face = "bold", color = "black"),
    axis.title.x = element_text(family =, size=20, face = "bold"),
    axis.title.y = element_text(family =, size=20, face = "bold"),
    legend.title = element_text(family =, size = 12, face = "bold", color = "black"),
    legend.text = element_text(family =, size = 10, face = "bold", color = "black"),
  )

