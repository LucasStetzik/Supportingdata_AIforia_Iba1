library(dplyr)

dat <- readxl::read_xlsx('Desktop/test/FILENAMEHERE.xlsx',
                         na = 'NA'
) 

results_updated2 <- dat %>% 
  
  filter(`Class label` != 'Tissue') %>%
  filter(Image %in% c(
    "2911 Iba1 posp 1of2",
    "3038 Iba1 posp 1of2",
    "2110 Iba1 posp 1of2",
    "3037 Iba1 posp 1of2",
    "2113 Iba1 posp 1of2",
    
    "1733 Iba1 posp 1of2",
    "2162 Iba1 posp 1of2",
    "1754 Iba1 posp 1of2",
    "2114  Iba1 posp 1of2",
    "2165 Iba1 posp 1of2"))


openxlsx::write.xlsx(results_updated2,'Desktop/test/FILENAMEHERE_PBSpffSubset.xlsx')
