library(tidyverse)
library(ggplot2)
library(dplyr)

#5 built from #4 but with legend adjustments ----------------------------------------------

library(showtext)
library(ggtext)

font_add_google(family="patua-one", "Patua One")
font_add_google(family="roboto", "Roboto")

showtext_auto()

AP_ratio_Matlab_aiforia_comparison_fig1_102921 %>%
  filter(AP >0) %>%
  filter(AP <3) %>%
  #filter(ROIumBYlewyum <1200) %>%
  #filter(ROIorder <7) %>%
  #filter(asynumBYlewyum <200) %>%
  #filter(counts100um <50) %>%
  #filter( lewyum > 0.8 ) %>%
  #dplyr::filter(BrainRegion == "Striatum")%>%
  
  #ggplot() +
  #geom_point(aes(x = method, y = AP, size = 0.1, alpha = 1, color = method))+
  #scale_color_manual(name ="Analysis method", values = colors3)+
  ##scale_size_continuous(name="Lewy body size μm²") +
  #scale_alpha(guide = 'none')+
  #guides(colour = guide_legend(override.aes = list(size=4)))+
  #guides(alpha=FALSE)+ # turn off specific legend alpha
  #guides(size=FALSE)+ # turn off specific legend alpha
  
  ggplot(aes(x = method, y = AP, size = pointsize, alpha = 1, color = method)) +
  scale_color_manual(name ="Analysis method", values = colors3)+
  geom_dotplot(binaxis = "y", binwidth=0.03, stackdir = "center", aes(fill=method, size = pointsize))+
  
  
  scale_alpha(guide = 'none')+
  guides(colour = guide_legend(override.aes = list(size=4)))+
  guides(alpha=FALSE)+ # turn off specific legend alpha
  guides(size=FALSE)+ # turn off specific legend alpha
  
  facet_wrap(~ BrainRegion + Image + ROI)+
  theme_classic()+
  
  #xlab("pSer129 μm²")+
  ylab("Area:Perimeter μm")+
  
  labs(#title = BrainRegion, # inserting "\n" in a string codes for a line break ex "happyn\birthday"
    subtitle = "",
    #caption = "<b>figure X: Comparison of TH+ cells across treatments:</b> Results suggest the treatment may affect the total number of cells and cell size in the anterior protion of the SN. Each point represents data extracted from the SN by hemisphere</i>", #<i> italics, <b> bold, <br> break
    tag = "",
    color = NULL,
    alpha = NULL)+
  
  theme(
    plot.title = element_textbox_simple(family = "patua-one", size=26, hjust = .3),
    #plot.title.position = "plot",
    plot.caption = element_textbox_simple(hjust =0.5, lineheight = 1), #textbox_simple does what markdown does but will autowrap texts "markdown includes html to render but needs ggtext in library loaded figure zero is left justified, one is right, and 0.5 is center
    #plot.subtitle =element_text(size = 95),
    axis.text.x = element_text(family ="patua-one", size = 12, face = "bold", color = "black"),
    axis.text.y = element_text(family ="patua-one", size = 12, face = "bold", color = "black"),
    axis.title.x = element_text(family =, size=20, face = "bold"),
    axis.title.y = element_text(family =, size=20, face = "bold"),
    legend.title = element_text(family =, size = 12, face = "bold", color = "black"),
    legend.text = element_text(family =, size = 10, face = "bold", color = "black"),
    strip.text = element_text(family ="patua-one", size = 12, face = "bold", color = "black"),
  )
colors3 <- c("aiforia" = "#D92D37", "MATLAB" = "#4F71B6")

